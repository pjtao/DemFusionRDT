
// DemFusionRDTDlg.h : header file
//

#pragma once


// CDemFusionRDTDlg dialog
class CDemFusionRDTDlg : public CDialogEx
{
// Construction
public:
	CDemFusionRDTDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DEMFUSIONRDT_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_strSrcDem;
	CString m_strAuxDem;
	CString m_strFusedDem;
	afx_msg void OnBrwSrc();
	afx_msg void OnBrwAux();
	afx_msg void OnBrwFus();
	afx_msg void OnOK();
};
