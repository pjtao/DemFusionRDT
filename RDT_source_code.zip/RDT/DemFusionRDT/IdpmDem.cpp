// IdpmDem.cpp: implementation of the CIdpmDem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IdpmDem.h"
#include <math.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CIdpmDem::CIdpmDem()
{
	m_pBuffer = NULL;
	m_nBufStCol = 0;
	m_nBufStRow = 0;
	m_nBufCols = 0;
	m_nBufRows = 0;
}

CIdpmDem::~CIdpmDem()
{
	Reset();
	m_demFile.Close();
}

BOOL CIdpmDem::Open(const char* lpstrPathName)
{
	Reset();

	if (!m_demFile.Open(lpstrPathName)){
		return FALSE;
	}

	return TRUE;
}

void CIdpmDem::Reset()
{
	if (m_pBuffer!=NULL){
		delete [] m_pBuffer; m_pBuffer = NULL;
	}

	m_nBufStCol = 0;
	m_nBufStRow = 0;
	m_nBufCols = 0;
	m_nBufRows = 0;
}

BOOL CIdpmDem::ReadData(int sRow, int sCol, int nRows, int nCols)
{
	Reset();

	int eRow = sRow+nRows-1;
	int eCol = sCol+nCols-1;
	sRow = max(0, sRow);
	sCol = max(0, sCol);
	eRow = min(m_demFile.GetRows()-1, eRow);
	eCol = min(m_demFile.GetCols()-1, eCol);

	m_nBufStCol = sCol;
	m_nBufStRow = sRow;
	m_nBufCols = eCol-sCol+1;
	m_nBufRows = eRow-sRow+1;
	if (m_nBufCols < 2 || m_nBufRows < 2){
		Reset();
		return FALSE;
	}
	
	try{
		m_pBuffer = new float[m_nBufCols*m_nBufRows];
		memset(m_pBuffer, 0, sizeof(float)*m_nBufCols*m_nBufRows);
	}
	catch (...){
		Reset();
		return FALSE;
	}
	
	BOOL bRead = m_demFile.Read(m_pBuffer, 1, m_nBufStRow, m_nBufStCol, m_nBufRows, m_nBufCols, 
		GDT_Float32);
	
	return bRead;
}

BOOL CIdpmDem::Interpolation(double gx, double gy, double* gz)
{
	*gz = NOVALUE;

	double OffsetX, OffsetY;
	OffsetX = OffsetY = -1.0;
	m_demFile.GeoProjToImage(gx, gy, &OffsetX, &OffsetY);
	OffsetX -= m_nBufStCol;
	OffsetY -= m_nBufStRow;

	if (OffsetX < 0 || OffsetX > m_nBufCols-1 ||
		OffsetY < 0 || OffsetY > m_nBufRows-1)
	{
		return FALSE;
	}

	long   Index;
	double DeltaX, DeltaY;
	float  z00, z01, z10, z11;
	double UpperY, LowerY;
	double PostX, PostY;
		
	PostX = floor( OffsetX ); if ((PostX + 1) == m_nBufCols) PostX--;
	PostY = floor( OffsetY ); if ((PostY + 1) == m_nBufRows) PostY--;
	
	Index = (long)(PostY * m_nBufCols + PostX);
	z00 = m_pBuffer[ Index ];
	z01 = m_pBuffer[ Index+ 1 ];
	
	Index = (long)((PostY + 1) * m_nBufCols + PostX);
	z10 = m_pBuffer[ Index ];
	z11 = m_pBuffer[ Index + 1 ];
	if (z00==NOVALUE || z01==NOVALUE || 
		z10==NOVALUE || z11==NOVALUE)
	{
		*gz = NOVALUE;
		return FALSE;
	}
	
	DeltaX = OffsetX - PostX;
	DeltaY = OffsetY - PostY;
	
	UpperY = z10 + DeltaX * ( z11 - z10 );
	LowerY = z00 + DeltaX * ( z01 - z00 );
	
	*gz = LowerY*(1 - DeltaY) + UpperY*DeltaY;

	return TRUE;
}

bool CIdpmDem::PhotoToGround(double px, double py, double* gx, double* gy) {
	m_demFile.ImageToGeoProj(px, py, gx, gy);
	return true;
}

bool CIdpmDem::GroundToPhoto(double gx, double gy, double* px, double* py) {
	m_demFile.GeoProjToImage(gx, gy, px, py);
	return true;
}

//////////////////////////////////////////////////////////////////////////
// CIdpmDemEx

CIdpmDemEx::CIdpmDemEx()
{
	m_pResampBuf = NULL;
	m_nCols = m_nRows = 0;
	memset(m_geoTrans, 0, sizeof(double)*12);
	m_bResampBuf = FALSE;
}

CIdpmDemEx::~CIdpmDemEx()
{
	if (m_pResampBuf!=NULL){
		delete [] m_pResampBuf;
		m_pResampBuf = NULL;
	}
}

BOOL CIdpmDemEx::Interpolation(double gx, double gy, double* gz)
{
	*gz = NOVALUE;
	if (!m_bResampBuf){
		return CIdpmDem::Interpolation(gx, gy, gz);
	}

	double OffsetX, OffsetY;
	OffsetX = OffsetY = -1.0;

	double* pGeoMatrix6 = m_geoTrans+6;
	OffsetX = pGeoMatrix6[0] + pGeoMatrix6[1]*gx + pGeoMatrix6[2]*gy;
	OffsetY = pGeoMatrix6[3] + pGeoMatrix6[4]*gx + pGeoMatrix6[5]*gy;
	
	if (OffsetX < 0 || OffsetX > m_nCols-1 ||
		OffsetY < 0 || OffsetY > m_nRows-1)
	{
		return FALSE;
	}
	
	long   Index;
	double DeltaX, DeltaY;
	float  z00, z01, z10, z11;
	double PostX, PostY;
	double UpperY, LowerY;
	
	PostX = floor( OffsetX ); if ((PostX + 1) == m_nCols) PostX--;
	PostY = floor( OffsetY ); if ((PostY + 1) == m_nRows) PostY--;
	
	Index = (long)(PostY * m_nCols + PostX);
	z00 = m_pResampBuf[ Index ];
	z01 = m_pResampBuf[ Index+ 1 ];
	
	Index = (long)((PostY + 1) * m_nCols + PostX);
	z10 = m_pResampBuf[ Index ];
	z11 = m_pResampBuf[ Index + 1 ];
	if (z00==NOVALUE || z01==NOVALUE || 
		z10==NOVALUE || z11==NOVALUE)
	{
		*gz = NOVALUE;
		return FALSE;
	}
	
	DeltaX = OffsetX - PostX;
	DeltaY = OffsetY - PostY;
	
	UpperY = z10 + DeltaX * ( z11 - z10 );
	LowerY = z00 + DeltaX * ( z01 - z00 );
	
	*gz = LowerY*(1 - DeltaY) + UpperY*DeltaY;
	
	return TRUE;
}

bool CIdpmDemEx::PhotoToGround(double px, double py, double* gx, double* gy) {
	if (m_bResampBuf){
		double* pGeoMatrix6 = m_geoTrans;
		*gx = pGeoMatrix6[0] + pGeoMatrix6[1] * px + pGeoMatrix6[2] * py;
		*gy = pGeoMatrix6[3] + pGeoMatrix6[4] * px + pGeoMatrix6[5] * py;
		return true;
	}

	return CIdpmDem::PhotoToGround(px, py, gx, gy);
}

bool CIdpmDemEx::GroundToPhoto(double gx, double gy, double* px, double* py) {
	if (m_bResampBuf){
		double* pGeoMatrix6 = m_geoTrans + 6;
		*px = pGeoMatrix6[0] + pGeoMatrix6[1] * gx + pGeoMatrix6[2] * gy;
		*py = pGeoMatrix6[3] + pGeoMatrix6[4] * gx + pGeoMatrix6[5] * gy;
		return true;
	}

	return CIdpmDem::GroundToPhoto(gx, gy, px, py);
}

float CIdpmDemEx::Interpolation(double x, double y) {

	double z = 0;
	if (!Interpolation(x, y, &z) || z < -9000.0f) {
		return NOVALUE;
	}

	return (float)z;
}