// IdpmDem.h: interface for the CIdpmDem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IDPMDEM_H__8CBFD883_7F16_48AD_B1F6_B10066DC0D5E__INCLUDED_)
#define AFX_IDPMDEM_H__8CBFD883_7F16_48AD_B1F6_B10066DC0D5E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IdpmImage.h"

#ifndef NOVALUE
#define NOVALUE						-99999
#endif

class CIdpmDem  
{
public:
	CIdpmDem();
	virtual ~CIdpmDem();

public:
	BOOL Open(const char* lpstrPathName);
	BOOL ReadData(int sRow, int sCol, int nRows, int nCols);

//	virtual BOOL ReadData(double minX, double minY, double maxX, double maxY, double maxGsd = 0);
	virtual BOOL Interpolation(double gx, double gy, double* gz);
	virtual bool PhotoToGround(double px, double py, double* gx, double* gy);
	virtual bool GroundToPhoto(double gx, double gy, double* px, double* py);

	void Reset();
	int GetCols() { return m_demFile.GetCols(); };
	int GetRows() { return m_demFile.GetRows(); };
	const float* GetDemBuffer() { return m_pBuffer; };
	
protected:
	CIdpmImage m_demFile;
	float* m_pBuffer;
	int m_nBufCols, m_nBufRows;
	int m_nBufStCol;
	int m_nBufStRow;
	BOOL m_bResampBuf;
};

class CIdpmDemEx : public CIdpmDem
{
public:
	CIdpmDemEx();
	virtual ~CIdpmDemEx();

public:
//	virtual BOOL ReadData(double minX, double minY, double maxX, double maxY, double maxGsd = 0);
	virtual BOOL Interpolation(double gx, double gy, double* gz);
	virtual bool PhotoToGround(double px, double py, double* gx, double* gy);
	virtual bool GroundToPhoto(double gx, double gy, double* px, double* py);
	float Interpolation(double x, double y);

protected:
	double m_geoTrans[12];
	int m_nCols, m_nRows;
	float* m_pResampBuf;
};

#endif // !defined(AFX_IDPMDEM_H__8CBFD883_7F16_48AD_B1F6_B10066DC0D5E__INCLUDED_)
