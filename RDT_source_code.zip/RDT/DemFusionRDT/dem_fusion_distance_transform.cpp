//////////////////////////////////////////////////////////////////////////
// dem_fusion_distance_transform.c

#include "stdafx.h"
#include "IdpmImage.h"
#include "IdpmDem.h"

#include <math.h>
#include <float.h>
#include <io.h>
#include <stdlib.h>


BOOL SaveImage(const char* lpstrPathName, void* pBuffer, int nCols, int nRows,
	int nBands, GDALDataType nType, double* pGeoTrans = NULL)
{
	GDALAllRegister();
	char strName[32] = "GTiff", strExt[256] = "";
	_splitpath(lpstrPathName,NULL,NULL,NULL,strExt);
	if (stricmp(strExt, ".IMG")==0){
		strcpy(strName, "HFA");
	}
	GDALDriver* pTiffDriver = GetGDALDriverManager()->GetDriverByName(strName);
	pTiffDriver->Delete(lpstrPathName);
	GDALDataset* pDataset = (GDALDataset*)pTiffDriver->Create(lpstrPathName,
		nCols, nRows, nBands, nType, NULL);
	if (pDataset==NULL){
		return FALSE;
	}

	int nBytes = GDALGetDataTypeSizeBytes(nType);
	int nRowSize = nCols*nBytes;
	SwapUpdown(pBuffer, nRows, nRowSize);

	int aBandMap[8] = { 1,2,3,4,5,6,7,8 };
	pDataset->RasterIO(GF_Write, 0, 0, nCols, nRows, pBuffer, nCols, nRows,
		nType, nBands, aBandMap, 0, 0, 0);
	if (pGeoTrans!=NULL){
		pDataset->SetGeoTransform(pGeoTrans);
	}

	pDataset->FlushCache();
	GDALClose(pDataset); pDataset = NULL;

	return TRUE;
}

// kernel function
void CreateDistFunction(const BYTE* pMask, int nCols, int nRows, float** pDistWeight) {
	if (*pDistWeight!=NULL) {
		delete[] *pDistWeight; *pDistWeight = NULL;
	}

	float D0 = sqrtf(float(nCols*nCols+nRows*nRows));
	float* pWeight = new float[nCols*nRows];
	const BYTE* pM = pMask; float* pW = pWeight;
	for (int i = 0; i < nRows; i++) {
		for (int j = 0; j < nCols; j++,pM++,pW++) {
			*pW = (*pM==255)?0.0f:D0;
		}
	}

	float fSqrt2 = sqrtf(2.0f);
	float fSqrt5 = sqrtf(5.0f);

	for (int i = 2; i < nRows - 2; i++) {
		for (int j = 2; j < nCols - 2; j++) {
			float* pRow0 = pWeight+nCols*i;
			float* pRow1 = pWeight+nCols*(i-1);
			float* pRow2 = pWeight+nCols*(i-2);

			pRow0[j] = min(pRow0[j], pRow1[j-1]+fSqrt2);
			pRow0[j] = min(pRow0[j], pRow1[j]+1);
			pRow0[j] = min(pRow0[j], pRow1[j+1]+fSqrt2);
			pRow0[j] = min(pRow0[j], pRow0[j-1]+1);

			pRow0[j] = min(pRow0[j], pRow1[j-2]+fSqrt5);
			pRow0[j] = min(pRow0[j], pRow1[j+2]+fSqrt5);
			pRow0[j] = min(pRow0[j], pRow2[j-1]+fSqrt5);
			pRow0[j] = min(pRow0[j], pRow2[j+1]+fSqrt5);
		}
	}

	for (int i = nRows-3; i >= 3; i--) {
		for (int j = nCols-3; j >= 3; j--) {
			float* pRow0 = pWeight + nCols*i;
			float* pRow1 = pWeight + nCols*(i+1);
			float* pRow2 = pWeight + nCols*(i+2);

			pRow0[j] = min(pRow0[j], pRow1[j+1]+fSqrt2);
			pRow0[j] = min(pRow0[j], pRow1[j]+1);
			pRow0[j] = min(pRow0[j], pRow1[j-1]+fSqrt2);
			pRow0[j] = min(pRow0[j], pRow0[j+1]+1);

			pRow0[j] = min(pRow0[j], pRow2[j+1]+fSqrt5);
			pRow0[j] = min(pRow0[j], pRow2[j-1]+fSqrt5);
			pRow0[j] = min(pRow0[j], pRow1[j+2]+fSqrt5);
			pRow0[j] = min(pRow0[j], pRow1[j-2]+fSqrt5);
		}
	}

	*pDistWeight = pWeight;
}

bool DemFusionWithRefData(const char* lpstrDemFile, const char* lpstrRef4Dem, 
	const char* lpstrResutDem)
{
	// Step 1, create mask for the DEM
	CIdpmImage demFile; CIdpmDemEx demRef;
	if (!demFile.Open(lpstrDemFile) || !demRef.Open(lpstrRef4Dem)){
		return false;
	}
	int nCols = demFile.GetCols();
	int nRows = demFile.GetRows();
	float* pDemBuf = new float[nCols*nRows];
	demFile.Read(pDemBuf, 1, 0, 0, nRows, nCols, GDT_Float32);

	BYTE* pMask = new BYTE[nCols*nRows];
	memset(pMask, 0, sizeof(BYTE)*nCols*nRows);

	for (int i=0; i<nRows; i++) {
		const float* pRowDem = pDemBuf+nCols*i;
		BYTE* pRowMsk = pMask+nCols*i;

		for (int j=0; j<nCols; j++,pRowDem++,pRowMsk++) {
			// Grids with height values less than -1000 or invalid values
			// are considered to be void areas
			if (*pRowDem < -1000.0 || _isnan(*pRowDem)){
				*pRowMsk = 255;
			}
		}
	}

	double* pGeoTransNew = NULL;
	double* pGeoTrans = demFile.GetGeoTransform();
	if (pGeoTrans != NULL) {
		pGeoTransNew = new double[6];
		memcpy(pGeoTransNew, pGeoTrans, sizeof(double) * 6);
	}

	// Step 2, create weight map based on raster distance transform
	float* pWeight = NULL;
	CreateDistFunction(pMask, nCols, nRows, &pWeight);

	// Step 3, dem fusion using the above weight map
	int nColsRef = demRef.GetCols();
	int nRowsRef = demRef.GetRows();
	demRef.ReadData(0, 0, nRowsRef, nColsRef);

	const int nFeatheringPixels = 32;
#pragma omp parallel for
	for (int i = 0; i < nRows; i++) {
		float* pRowD = pDemBuf+nCols*i;
		float* pRowW = pWeight+nCols*i;
		BYTE* pRowM = pMask+nCols*i;
		double gx, gy; float gz; float weight = 0.0;
		for (int j = 0; j < nCols; j++) {

			demFile.ImageToGeoProj(j, i, &gx, &gy);
			gz = demRef.Interpolation(gx, gy);

			// invalid dem height
			if (gz==NOVALUE || gz<-1000.0f) {
				continue;
			}

			if (pRowW[j] < 0.001 && pRowM[j]==255) {
				// void areas
				pRowD[j] = gz;
			}
			else if (pRowW[j] < nFeatheringPixels && pRowM[j] != 255) {
				// buffer zone
				weight = pRowW[j] / nFeatheringPixels;
				pRowD[j] = pRowD[j] * weight + gz*(1 - weight);
			}
		}
	}

	demFile.Close();
	demRef.Reset();

	SaveImage(lpstrResutDem, pDemBuf, nCols, nRows, 1, GDT_Float32, pGeoTransNew);

	if (pDemBuf!=NULL){
		delete[] pDemBuf; pDemBuf = NULL;
	}
	if (pMask!=NULL){
		delete[] pMask; pMask = NULL;
	}
	if (pWeight!=NULL){
		delete[] pWeight; pWeight = NULL;
	}
	if (pGeoTransNew!=NULL) {
		delete[] pGeoTransNew; pGeoTransNew = NULL;
	}

	return true;
}