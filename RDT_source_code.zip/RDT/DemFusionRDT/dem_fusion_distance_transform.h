//////////////////////////////////////////////////////////////////////////
// dem_fusion_distance_transform.h

#ifndef _DEM_FUSION_DISTANCE_TRANSFORM_H
#define _DEM_FUSION_DISTANCE_TRANSFORM_H

bool DemFusionWithRefData(const char* lpstrDemFile, const char* lpstrRef4Dem,
	const char* lpstrResutDem);

#endif
