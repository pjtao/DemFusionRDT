
/*++

Module Name:

    IdpmImage.

Abstract:

    This module contains the C++ class for reading/writing raster files.

--*/

#ifndef IDPMIMAGE_H_
#define IDPMIMAGE_H_

#include "GDAL/gdal.h"
#include "GDAL/gdal_priv.h"
#include "GDAL/cpl_conv.h"

#ifndef NULL
#  define NULL  0
#endif

#ifndef FALSE
#  define FALSE 0
#endif

#ifndef TRUE
#  define TRUE  1
#endif

inline void SwapUpdown(void* pBuffer, int nRows, int nRowSize)
{
	BYTE* pRow = new BYTE[nRowSize];
	memset(pRow, 0, nRowSize);
	for (int i = 0; i < nRows / 2; i++) {
		BYTE* pL = (BYTE*)pBuffer + nRowSize*i;
		BYTE* pU = (BYTE*)pBuffer + nRowSize*(nRows - i - 1);

		memcpy(pRow, pL, nRowSize);
		memcpy(pL, pU, nRowSize);
		memcpy(pU, pRow, nRowSize);
	}
	delete[] pRow; pRow = NULL;
}

class CIdpmImage
{
public:
	CIdpmImage()
	{
		m_pGDALDataset = NULL;
		memset(m_lfGeoTransform, 0, sizeof(m_lfGeoTransform));
	}
	virtual ~CIdpmImage()
	{
		Close();
	}

	enum OPENFLAGS
	{
		modeRead = 0x0000,
		modeCreate = 0x1000,
	};

public:
	virtual BOOL Open(const char* lpstrPathName, int flag = modeRead)
	{
		Close();
		CPLSetConfigOption("GDAL_FILENAME_IS_UTF8", "NO");
		GDALAllRegister();

		if (flag==modeRead){
			m_pGDALDataset = (GDALDataset*)GDALOpen(lpstrPathName, GA_ReadOnly);
			if (m_pGDALDataset==NULL){
				return FALSE;
			}

			m_pGDALDataset->GetGeoTransform(m_lfGeoTransform);

			double* geoTrans6 = m_lfGeoTransform;
			double inv[6];
			double t = (geoTrans6[1] * geoTrans6[5] - geoTrans6[2] * geoTrans6[4]);
			inv[1] = geoTrans6[5] / t; inv[2] = -geoTrans6[2] / t;
			inv[4] = -geoTrans6[4] / t; inv[5] = geoTrans6[1] / t;
			inv[0] = -geoTrans6[0] * inv[1] - geoTrans6[3] * inv[2];
			inv[3] = -geoTrans6[0] * inv[4] - geoTrans6[3] * inv[5];
			memcpy(m_lfGeoTransform+6, inv, sizeof(double)*6);

		}
		else{
			return FALSE;
		}

		return TRUE;
	}

	virtual void Close()
	{
		if (m_pGDALDataset != NULL) {
			GDALClose(m_pGDALDataset);
			m_pGDALDataset = NULL;
		}
		memset(m_lfGeoTransform, 0, sizeof(m_lfGeoTransform));
	}

	virtual BOOL Read(void* pBuffer, int nBands, int sRow, int sCol,
		int nRows, int nCols, GDALDataType eType = GDT_Byte)
	{
		if (pBuffer==NULL || nRows<1 || nCols<1){
			return FALSE;
		}
		if (m_pGDALDataset==NULL){
			return FALSE;
		}

		// bottom left to top left
		int nImgCols = m_pGDALDataset->GetRasterXSize();
		int nImgRows = m_pGDALDataset->GetRasterYSize();

		sRow = nImgRows-(sRow+nRows);
		int aBandMap[8] = { 1,2,3,4,5,6,7,8 };
		CPLErr nError = m_pGDALDataset->RasterIO(GF_Read, sCol, sRow, nCols, nRows, pBuffer,
			nCols, nRows, eType, nBands, aBandMap, 0, 0, 0);

		// swap memory
		int nBytes = GDALGetDataTypeSizeBytes(eType);
		int nRowSize = nCols*nBytes;
		SwapUpdown(pBuffer, nRows, nRowSize);

		return (nError == CE_None) ? TRUE : FALSE;
	}

public:
	int	GetRows()
	{
		if (m_pGDALDataset == NULL) {
			return 0;
		}
		return m_pGDALDataset->GetRasterYSize();
	};
	int	GetCols()
	{
		if (m_pGDALDataset ==NULL) {
			return 0;
		}
		return m_pGDALDataset->GetRasterXSize();
	};
	int	GetBands()
	{
		if (m_pGDALDataset == NULL) {
			return 0;
		}
		return m_pGDALDataset->GetRasterCount();
	};
	int GetDataType()
	{
		if (m_pGDALDataset == NULL) {
			return 0;
		}
		return (int)m_pGDALDataset->GetRasterBand(1)->GetRasterDataType();
	};

	virtual double*	GetGeoTransform()
	{
		if (m_pGDALDataset == NULL) {
			return NULL;
		}

		return m_lfGeoTransform;
	};

	void ImageToGeoProj(double ix, double iy, double* gx, double* gy)
	{
		int nRows = this->GetRows();
		double ny = nRows-iy-1;
		*gx = m_lfGeoTransform[0]+m_lfGeoTransform[1]*ix+m_lfGeoTransform[2]*ny;
		*gy = m_lfGeoTransform[3]+m_lfGeoTransform[4]*ix+m_lfGeoTransform[5]*ny;
	};
	
	void GeoProjToImage(double gx, double gy, double* ix, double* iy)
	{
		double* pGeoTransform = m_lfGeoTransform + 6;
		*ix = pGeoTransform[0] + pGeoTransform[1] * gx + pGeoTransform[2] * gy;
		*iy = pGeoTransform[3] + pGeoTransform[4] * gx + pGeoTransform[5] * gy;

		int nRows = this->GetRows();
		*iy = nRows-(*iy)-1;
	};

protected:
	GDALDataset* m_pGDALDataset;
	double m_lfGeoTransform[12];
};

#endif